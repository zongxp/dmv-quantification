function res=half2(x)

   if mod(x,2) == 0
       res=x/2+1;
   else
      res = (x+1)/2; 
   end